#!/usr/bin/env python3
from brain_games.games.games_prime import test_prime_numbers


def main():
    test_prime_numbers()


if __name__ == '__main__':
    main()
