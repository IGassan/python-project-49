#!/usr/bin/env python3
from brain_games.games.games_gcd import gcd


def main():
    gcd()


if __name__ == '__main__':
    main()
