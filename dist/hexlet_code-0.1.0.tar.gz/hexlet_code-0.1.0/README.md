### Hexlet tests and linter status:
[![Actions Status](https://github.com/IGassan/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/IGassan/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/4620352db121d5a9bc18/maintainability)](https://codeclimate.com/github/IGassan/python-project-49/maintainability)

# Ссылка на аскинему brain-even
https://asciinema.org/a/PhxSS76cWaEnZGtLbC1moq0tM

# Ссылка на аскинему brain-calc
https://asciinema.org/a/fLX2BTCMgBJ1qvJu7BRWybuIM