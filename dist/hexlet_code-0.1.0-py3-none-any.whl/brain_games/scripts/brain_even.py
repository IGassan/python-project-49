#!/usr/bin/env python3
from brain_games.games.games_even import parity_check


def main():
    parity_check()


if __name__ == '__main__':
    main()
